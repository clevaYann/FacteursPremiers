package com.jarlin.facteursPremiers;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}


